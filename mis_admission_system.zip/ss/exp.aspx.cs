﻿using System.Data;
using System.Configuration;
using System.Data.SqlClient;
using System;
using System.Web.UI.WebControls;
using System.Web;

public partial class exp : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            BindRepeater();
        }
    }

    protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        int index = Convert.ToInt32(e.CommandArgument);
        if (e.CommandName.Equals("detail"))
        {
            GridViewRow gvrow = GridView1.Rows[index];
            string quer = "SELECT * FROM hostelMaster where RegID= @lblreg";
            SqlParameter para = new SqlParameter();
            para.ParameterName = "@lblreg";
            para.Value = HttpUtility.HtmlDecode(gvrow.Cells[0].Text).ToString();
            using (SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["GECAConnectionString"].ToString()))
            {
                conn.Open();
                using (SqlCommand command = new SqlCommand(quer, conn))
                {
                    command.Parameters.Add(para);
                    SqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {

                    }
                }
                conn.Close();
            }
        }
    }
    private void BindRepeater()
    {
        using (SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["GECAConnectionString"].ToString()))
        {
            using (SqlCommand cmd = new SqlCommand())
            {
                cmd.CommandText = "select * from hostelMaster";
                
                cmd.Connection = con;
                con.Open();
                GridView1.DataSource = cmd.ExecuteReader();
                GridView1.DataBind();
                con.Close();
            }
        }
    }
}