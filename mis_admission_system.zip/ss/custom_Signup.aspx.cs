﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class studlogin : System.Web.UI.Page
{
    SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["GECAConnectionString"].ToString());
    protected void Page_Load(object sender, EventArgs e)
    {
        suc_lbl.Visible = false;
        err_lbl.Visible = false;
    }
    protected void signup_click(object sender, EventArgs e)
    {
        if (pass.Text.ToString().Count() <= 10)
        {
            func_signup();
        }
        else
        {
            pass_lbl.Text = "<z style='color: #c00'>*Max 10 characters in Password!</z>";
        }
    }

    public void func_signup()
    {
        string em = TextBox2.Text.ToLower();
        string quer = "SELECT regID from [Gecausers] where email = @email";
        SqlParameter para = new SqlParameter();
        para.ParameterName = "@email";
        para.Value = em;
        //int i=0;
        string i = null;
        using (conn)
        {
            conn.Open();
            using (SqlCommand command = new SqlCommand(quer, conn))
            {
                command.Parameters.Add(para);
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    i = reader["regID"].ToString();
                }
            }
            conn.Close();
        }
        if (i == null)
        {
            string ac = null;
            using (StudMasterClassDataContext context = new StudMasterClassDataContext())
            {
                Gecauser studmas = new Gecauser();
                studmas.Password = pass.Text;
                studmas.email = em;
                context.Gecausers.InsertOnSubmit(studmas);
                context.SubmitChanges();
            }
            string quer2 = "SELECT regID from[Gecausers] where email = @email";
            SqlParameter para2 = new SqlParameter();
            para2.ParameterName = "@email";
            para2.Value = em;
            using (SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["GECAConnectionString"].ToString()))
            {
                conn.Open();
                using (SqlCommand command = new SqlCommand(quer2, conn))
                {
                    command.Parameters.Add(para2);
                    SqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        ac = reader["regID"].ToString();
                    }
                }
                conn.Close();
            }
            using (StudMasterClassDataContext context = new StudMasterClassDataContext())
            {
                StudMaster studmas = new StudMaster();
                Guid guid1 = Guid.NewGuid();
                studmas.name = name.Text.ToUpper();
                studmas.regID = ac;
                studmas.addr = addr.Text;
                studmas.mobno = TextBox3.Text;
                studmas.email = em;
                studmas.astream = astream.Text;
                studmas.ayear = ayear.Text;
                studmas.guid1 = guid1.ToString();
                context.StudMasters.InsertOnSubmit(studmas);
                context.SubmitChanges();
                form1.Visible = false;
                suc_lbl.Visible = true;
            }

            string quer22 = "SELECT regID from[Gecausers] where email = @email";
            SqlParameter para22 = new SqlParameter();
            para22.ParameterName = "@email";
            para22.Value = em;
            using (SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["GECAConnectionString"].ToString()))
            {
                conn.Open();
                using (SqlCommand command = new SqlCommand(quer22, conn))
                {
                    command.Parameters.Add(para22);
                    SqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        ac = reader["regID"].ToString();
                    }
                }
                conn.Close();
            }
            suc2_lbl.Text = "<p style='font-size: 20px; color: green;'>Registration is Successful!</p><p style='font-size: 13px; color: green;'>Your Registration ID is: <u>"+ac+"</u></p><p class='to_register'><a href='login.aspx'>Click here</a> to Sign in</p>";
            suc2_lbl.Visible = true;
        }
        else
            err_lbl.Visible = true;
    }
}
