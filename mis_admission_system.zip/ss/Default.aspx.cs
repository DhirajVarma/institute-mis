﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data;
using System.Web.UI.HtmlControls;
using System.Xml.Linq;
using System.IO;

public partial class _Default : System.Web.UI.Page
{

    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["GECAConnectionString"].ToString());
    protected void Page_Load(object sender, EventArgs e)
    {
        for (int i = 1; i <= 89; i++)
            {
                roomno.Items.Add(new ListItem(i.ToString(), i.ToString()));
            }

        if (Session["New"] != null)
        {
            string te;
            using (con)
            {
                string comman = "select guid1 from hostelMaster where RegID= @reg";
                using (SqlCommand command = new SqlCommand(comman, con))
                {
                    command.Parameters.AddWithValue("@reg", Session["New"].ToString());
                    con.Open();
                    te = (string)command.ExecuteScalar();
                    SqlDataReader reader = command.ExecuteReader();
                    if (reader.HasRows)
                    {
                        con.Close();
                        Response.Redirect("conf.aspx?gid=" + te);
                    }
                    con.Close();
                }
            }
        }
        else Response.Redirect("login.aspx");

    }


    protected void Button1_Click(object sender, EventArgs e)
    {
        try
        {
            savestudinfo();
        }
        catch(Exception)
        {
            Response.Write("Somethings messy happened...!\n\nPlease try again!");
        }
    }
    
    protected void Button4_Click(object sender, EventArgs e)
    {
        Session.Clear();
        Session.Abandon();
        Response.Redirect("login.aspx");
    }
    
    public void savestudinfo()
    {
        string upfolder = @"Uploads\";
        string exten = Path.GetExtension(FileUpload1.FileName);
        string ufilen = Path.ChangeExtension(FileUpload1.FileName, DateTime.Now.Ticks.ToString());
        string exten2 = Path.GetExtension(FileUpload2.FileName);
        string ufilen2 = Path.ChangeExtension(FileUpload2.FileName, DateTime.Now.Ticks.ToString());
        string ufilN1 = upfolder + ufilen + exten;
        string ufilN2 = upfolder + ufilen2 + exten2;
        using (hostelClassDataContext context = new hostelClassDataContext())
        {
            string fullName = firstN.Text + " " + middleN.Text + " " + LastN.Text;
            string dobir = dobd.Text + "-" + dobm.Text + "-" + doby.Text;
            string pht = "NA";
            if(isPh.Text == "Yes")
            {
                pht = phtype.Text;
            }

            Guid guid1= Guid.NewGuid();
            hostelMaster studmas = new hostelMaster();
            studmas.name = fullName.ToUpper();
            studmas.roomno = roomno.Text;
            studmas.bstate = state.Text;
            studmas.addr = addr.Text;
            studmas.localaddr = laddr.Text;
            studmas.selfmobNo = mobno.Text;
            studmas.parmobNo = pmobno.Text;
            studmas.email = emailaddr.Text.ToLower();
            studmas.dob = dobir;
            studmas.astream = deptName.Text;
            studmas.ayear = deptYear.Text;
            studmas.religio = religio.Text;
            studmas.commun = commun.Text;
            studmas.isph = pht;
            studmas.path = ufilN1;
            studmas.sign2 = ufilN2;
            studmas.guid1 = guid1.ToString();
            studmas.conftime = DateTime.Now.ToString();

            context.hostelMasters.InsertOnSubmit(studmas);
            context.SubmitChanges();
            FileUpload1.SaveAs(Server.MapPath(upfolder) + ufilen + exten);
            FileUpload2.SaveAs(Server.MapPath(upfolder) + ufilen2 + exten2);
            
            Response.Redirect("conf.aspx?gid=" + guid1);
        }
    }
}


