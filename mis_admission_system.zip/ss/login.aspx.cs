﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

public partial class login : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["GECAConnectionString"].ToString());

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            Session.Clear();
            Session.RemoveAll();
            Session.Abandon();
        }
    }

    protected void login_click(object sender, EventArgs e)
    {
        try
        {
            StudMasterClassDataContext context = new StudMasterClassDataContext();
            var quer = from p in context.Gecausers where p.regID == uname.Text && p.Password == pass.Text select p;
            if (quer.Any())
            {
                Session["student34i7563487634io68734"] = uname.Text;
                Response.Redirect("dashboard.aspx");
            }
            else err_msg.Text = "Invalid Credentials!";
        }
        catch(Exception)
        {
            Response.Write("<script>alert('Something messy happened! Please try again!');</script>");
        }
    }
}