﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class trial : System.Web.UI.Page
{
    DataTable dt;
    SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["GECAConnectionString"].ToString());
    protected void Page_Load(object sender, EventArgs e)
    {
        Bind();
    }
    
    protected void Bind()
    {
        conn.Open();
        string cmd = "select * from hostelMaster";
        SqlDataAdapter dAdapter = new SqlDataAdapter(cmd, conn);
        DataSet ds = new DataSet();
        dAdapter.Fill(ds);
        DataTable dt = ds.Tables[0];
        GridView1.DataSource = dt;
        GridView1.DataBind();
        GridView1.HeaderRow.TableSection = TableRowSection.TableHeader;
        GridView1.FooterRow.TableSection = TableRowSection.TableFooter;
    }


    protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        int index = Convert.ToInt32(e.CommandArgument);
        if (e.CommandName.Equals("detail"))
        {
            Response.Write("<script>kj</script>");
        }
    }
}
