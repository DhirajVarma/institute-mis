﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class hosadmin : System.Web.UI.Page
{
    DataTable dt;

    SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["GECAConnectionString"].ToString());
    protected void Page_Load(object sender, EventArgs e)
    {

        GridView1.HeaderRow.TableSection = TableRowSection.TableHeader;
        BindGrid();
    }

    public void BindGrid()
    {
        try
        {
            SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["GECAConnectionString"].ToString());
            conn.Open();
            string cmd = "select * from hostelMaster limit 10";
            SqlDataAdapter dAdapter = new SqlDataAdapter(cmd, conn);
            DataSet ds = new DataSet();
            dAdapter.Fill(ds);
            dt = ds.Tables[0];
            //Bind the fetched data to gridview
            GridView1.DataSource = dt;
            GridView1.DataBind();

        }
        catch (SqlException ex)
        {
            System.Console.Error.Write(ex.Message);

        }

    }

   
    protected void Button1_Click(object sender, EventArgs e)
    {
        Response.Redirect("exp.aspx");
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        Response.Redirect("exp.aspx");
    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        Response.Redirect("exp.aspx");
    }

}