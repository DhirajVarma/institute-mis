﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class office : System.Web.UI.Page
{
    SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["GECAConnectionString"].ToString());
    protected void Page_Load(object sender, EventArgs e)
    {
        countall();countappr();countconf();
            if (Session["studsecjsghewgelkerkj"] != null)
            {
                changeconfstatus.Visible = false;
                changeapprstatus.Visible = false;
                resssoffiframe.Visible = false;
                regformacnewusr.Visible = false;
                regformssnewusr.Visible = false;
                iddettable2.Visible = false;
                infotable.Visible = true;
                ssoff.Visible = false;
                acoff.Visible = false;
                acinfo.Visible = false;
                Div2.Visible = false;
                _11menu.Visible = false;
                _11_menu.Visible = false;
        }
        else if (Session["acc63582676541.504234654"] != null)
        {
            changeconfstatus.Visible = false;
            changeapprstatus.Visible = false;
            resssoffiframe.Visible = false;
            regformacnewusr.Visible = false;
            regformssnewusr.Visible = false;
            ssoff.Visible = false;
            acoff.Visible = false;
            iddettable2.Visible = false;
            infotable.Visible = false;
            acinfo.Visible = true;
            Div2.Visible = false;
            _11menu.Visible = false;
            _11_menu.Visible = false;
        }
        else if (Session["studsecoffi7658317tfkynuhgvrhy354"] != null)
        {
            changeconfstatus.Visible = false;
            changeapprstatus.Visible = false;
            resssoffiframe.Visible = false;
            iddettable2.Visible = false;
            infotable.Visible = false;
            acinfo.Visible = false;
            Div2.Visible = false;
            _10menu.Visible = false;
            acoff.Visible = false;
            resacoffiframe.Visible = false;
            regformacnewusr.Visible = false;
            _11_menu.Visible = false;
        }
        else if (Session["acoffidafghfasdfasdas6576867714789dsfsgfvdshgs"] != null)
        {

            changeconfstatus.Visible = false;
            changeapprstatus.Visible = false;
            resssoffiframe.Visible = false;
            iddettable2.Visible = false;
            infotable.Visible = false;
            acinfo.Visible = false;
            Div2.Visible = false;
            _10menu.Visible = false;
            ssoff.Visible = false;
            resssoffiframe.Visible = false;
            regformacnewusr.Visible = false;
            _11menu.Visible = false;
        }
        else
            {
                Session.Abandon();
                Session.Clear();
                Session.RemoveAll();
                iddettable2.Visible = false;
                infotable.Visible = false;
                acinfo.Visible = false;
                Div2.Visible = false;
                Response.Redirect("login.aspx");
            }
    }
    

    protected void searbutt(object sender, EventArgs e)
    {
        try
        {
            string quer = "SELECT * FROM StudMaster where regID= @lblreg";
            //SqlCommand rquer = new SqlCommand("SELECT count(*) from hostelMaster where roomno=@rnum");
            SqlParameter para = new SqlParameter();
            para.ParameterName = "@lblreg";
            para.Value = "GECAEN17" + TextBox1.Text;
            string ag = "False";
            string agt = "False";
            string tio = null;
            string arer = null;
            string confer = null;
            using (conn)
            {
                conn.Open();
                using (SqlCommand command = new SqlCommand(quer, conn))
                {
                    command.Parameters.Add(para);
                    SqlDataReader reader = command.ExecuteReader();
                    if (reader.HasRows)
                    {
                        errlabell.Visible = false;
                        iddettable2.Visible = true;
                        while (reader.Read())
                        {
                            namedetlbl.Text = reader["name"].ToString();
                            regiddetlbl.Text = reader["regID"].ToString();
                            addrdetlbl.Text = reader["addr"].ToString();
                            mobnodetlbl.Text = reader["mobno"].ToString();
                            emaildetlbl.Text = reader["email"].ToString();
                            genderdetlbl.Text = reader["gender"].ToString();
                            dobdetlbl.Text = reader["dob"].ToString();
                            reldetlbl.Text = reader["religion"].ToString();
                            commdetlbl.Text = reader["commun"].ToString();
                            astreamdetlbl.Text = reader["astream"].ToString();
                            ayeardetlbl.Text = reader["ayear"].ToString();
                            isphdetlbl.Text = reader["isph"].ToString();
                            nridetlbl.Text = reader["isnri"].ToString();
                            natdetlbl.Text = reader["isforeign"].ToString();
                            yoadetlbl.Text = reader["yofadmis"].ToString();
                            toadetlbl.Text = reader["typeofadmis"].ToString();
                            ciddetlbl.Text = reader["cid"].ToString();
                            cshiftdetlbl.Text = reader["cshift"].ToString();
                            cyeardetlbl.Text = reader["cyear"].ToString();
                            confer = reader["apprby"].ToString();
                            ag = reader["approvess"].ToString();
                            agt = reader["approveac"].ToString();
                            tio = reader["ssapprtime"].ToString();
                            arer = reader["formupdtcount"].ToString();
                            string a = reader["dp"].ToString();
                            ssrev.Text = reader["studsecrev"].ToString();
                            TextBox2.Text = reader["fees"].ToString();
                            dpdetlbl.Text = "<img src='" + a + "' style='width: 136px; height: 167px; left: 0; top: 0;'></img>";
                        }
                        ssbutt.Visible = true;
                        cbox1.Checked = false;
                    }
                    else
                    {
                        errlabell.Text = "<p class='alert alert-danger' style='margin-top: 25px; margin-bottom:25px'><strong>Err... Invalid Registration ID!</strong></p>";
                        errlabell.Visible = true;
                    }
                }
                conn.Close();
                if(arer == "False")
                {
                    iddettable2.Visible = false;
                    errlabell.Text = "<p class='alert alert-danger' style='margin-top: 25px; margin-bottom:25px'><strong>This user does not completed his registration process!</strong></p>";
                    errlabell.Visible = true;
                }
                if (ag == "True")
                {
                    cbox1.Checked = true;
                    cbox1.Enabled = false;
                    TextBox2.Enabled = false;
                    ssbutt.Visible = false;
                    ssrev.Enabled = false;
                    errlabell.Text = "<p class='alert alert-info' style='margin-top: 25px; margin-bottom:25px'><strong>The user "+confer+" has already approved this Registration ID for furthure process <br/> on <span style='font-weight: 600'>"+tio+"</span></strong></p>";
                    errlabell.Visible = true;
                }
                if (agt == "True")
                {
                    cbox1.Checked = true;
                    cbox1.Enabled = false;
                    TextBox2.Enabled = false;
                    ssbutt.Enabled = false;
                    ssrev.Enabled = false;
                    errlabell.Text = "<p class='alert alert-danger' style='margin-top: 25px; margin-bottom:25px'><strong>Accounts Section has already Confirmed the fees payment for this Registration ID ...</strong></p>";
                    errlabell.Visible = true;
                }
                else
                {
                    cbox1.Enabled = true;
                    TextBox2.Enabled = true;
                    ssbutt.Enabled = true;
                    ssrev.Enabled = true;
                }
            }
        }
        catch (Exception)
        {
            Response.Write("<script>alert('something really messy happened!\nPlease try again!');</script>");
        }
    }

    protected void searbutt2(object sender, EventArgs e)
    {
        try
        {
            string quer = "SELECT * FROM StudMaster where regID= @lblreg";
            SqlParameter para = new SqlParameter();
            para.ParameterName = "@lblreg";
            para.Value = "GECAEN17" + TextBox3.Text;
            string agt = "false";
            string ar = "";
            string confer = "";
            string arer = null;
            using (SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["GECAConnectionString"].ToString()))
            {
                conn.Open();
                using (SqlCommand command = new SqlCommand(quer, conn))
                {
                    command.Parameters.Add(para);
                    SqlDataReader reader = command.ExecuteReader();
                    if (reader.HasRows)
                    {
                        acerrlabel.Visible = false;
                        Div2.Visible = true;
                        while (reader.Read())
                        {
                            acnamedetlbl.Text = reader["name"].ToString();
                            acregiddetlbl.Text = reader["regID"].ToString();
                            acastreamdetlbl.Text = reader["astream"].ToString();
                            acayeardetlbl.Text = reader["ayear"].ToString();
                            acamntdetlbl.Text = reader["fees"].ToString();
                            acssrevdetlbl.Text = reader["studsecrev"].ToString();
                            acrev.Text = reader["accountantrev"].ToString();
                            confer = reader["confby"].ToString();
                            arer = reader["approvess"].ToString();
                            agt = reader["approveac"].ToString();
                            Label11.Text = reader["apprby"].ToString();
                            Label12.Text = reader["ssapprtime"].ToString();
                            ar = reader["fees"].ToString();
                            string a = reader["dp"].ToString();
                            acdpdetlbl.Text = "<img src='" + a + "' style='width: 136px; height: 167px; left: 0; top: 0;'></img>";
                        }
                    }
                    else
                    {
                        acerrlabel.Text = "<p class='alert alert-danger' style='margin-top: 25px; margin-bottom:25px'><strong>Err... Invalid Registration ID!</strong></p>";
                        acerrlabel.Visible = true;
                    }
                }
                conn.Close();
                if (arer == "False")
                {
                    Div2.Visible = false;
                    acerrlabel.Text = "<p class='alert alert-danger' style='margin-top: 25px; margin-bottom:25px'><strong>This user is not approved by Student Section Authority!</strong></p>";
                    acerrlabel.Visible = true;
                }
                if (agt == "True")
                {
                    cbox2.Checked = true;
                    cbox2.Enabled = false;
                    TextBox5.Text = ar;
                    TextBox5.Enabled = false;
                    Button1.Enabled = false;
                    acrev.Enabled = false;
                    acerrlabel.Text = "<p class='alert alert-info' style='margin-top: 25px; margin-bottom:25px'><strong> The user "+ confer + " has already confirmed the payment for this Registration ID</strong></p>";
                    acerrlabel.Visible = true;
                }
                else
                {
                    cbox2.Enabled = true;
                    TextBox5.Enabled = true;
                    Button1.Enabled = true;
                    acrev.Enabled = true;
                }
            }
        }
        catch (Exception)
        {
            Response.Write("<script>alert('something really messy happened!\nPlease try again!');</script>");
        }
    }


    protected void ssdone(object sender, EventArgs e)
    {
        try
        {
            if (cbox1.Checked)
            {
                    SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["GECAConnectionString"].ToString());
                conn.Open();
                    string updatecmd = "update StudMaster set approvess=1, fees=@fees, ssapprtime=@satime, apprby=@appr, studsecrev=@ssr where regID=@regid";
                    SqlCommand updateCmd = new SqlCommand(updatecmd, conn);
                    updateCmd.Parameters.AddWithValue("@ssr", ssrev.Text);
                    updateCmd.Parameters.AddWithValue("@fees", TextBox2.Text);
                    updateCmd.Parameters.AddWithValue("@regid", regiddetlbl.Text);
                    updateCmd.Parameters.AddWithValue("@appr", Session["studsecjsghewgelkerkj"].ToString());
                    updateCmd.Parameters.AddWithValue("@satime", DateTime.Now.ToString());
                    updateCmd.ExecuteNonQuery();
                    conn.Close();
                    errlabell.Text = "<p class='alert alert-success' style='margin-top: 25px; margin-bottom:25px'><strong>Registration ID: " + regiddetlbl.Text + " has been Approved for furthure process!</strong></p>";
                    errlabell.Visible = true;
            }
            else Response.Write("<script>alert('Have you confirmed the student details ?')</script>");
        }
        catch (Exception)
        {
            Response.Write("<script>alert('something really messy happened!\nPlease try again!');</script>");
        }
    }

    protected void searbuttssoff(object sender, EventArgs e)
    {
                string a = "GECAEN17"+TextBox4.Text.ToString();
                string urlo = "./io/changestat.aspx?rid=" + a;
                string s = "window.open('" + urlo + "', 'popup_window', 'width=900,height=400,left=100,top=100,resizable=yes');";
                ClientScript.RegisterStartupScript(this.GetType(), "script", s, true);
    }
    protected void searbuttacoff(object sender, EventArgs e)
    {
        string a = "GECAEN17" + TextBox6.Text.ToString();
        string urlo = "./io/changestat2.aspx?rid=" + a;
        string s = "window.open('" + urlo + "', 'popup_window', 'width=900,height=400,left=100,top=100,resizable=yes');";
        ClientScript.RegisterStartupScript(this.GetType(), "script", s, true);
    }

    protected void acdone(object sender, EventArgs e)
    {
        if (Convert.ToInt64(acamntdetlbl.Text) == Convert.ToInt64(TextBox5.Text))
        {
            try
            {
                if (cbox2.Checked)
                {
                    SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["GECAConnectionString"].ToString());
                    conn.Open();
                    string updatecmd = "update StudMaster set approveac=1, accountantrev=@ssr, acconftime=@satime, confby=@appr where regID=@regid";
                    SqlCommand updateCmd = new SqlCommand(updatecmd, conn);
                    updateCmd.Parameters.AddWithValue("@ssr", acrev.Text);
                    updateCmd.Parameters.AddWithValue("@appr", Session["acc63582676541.504234654"].ToString());
                    updateCmd.Parameters.AddWithValue("@regid", acregiddetlbl.Text);
                    updateCmd.Parameters.AddWithValue("@satime", DateTime.Now.ToString());
                    updateCmd.ExecuteNonQuery();
                    conn.Close();
                    acerrlabel.Text = "<p class='alert alert-success' style='margin-top: 25px; margin-bottom:25px'><strong>Payment has been Confirmed for Registration ID: " + acregiddetlbl.Text + "!</strong></p>";
                    acerrlabel.Visible = true;
                }
                else
                {
                    acerrlabel.Text = "<p class='alert alert-danger' style='margin-top: 25px; margin-bottom:25px'><strong>Have you confirmed the payment ?</strong></p>";
                    acerrlabel.Visible = true;
                }
            }
            catch (Exception)
            {
                Response.Write("<script>alert('something really messy happened!\nPlease try again!');</script>");
            }
        }
        else
        {
            Div2.Visible = true;
            acerrlabel.Text = "<p class='alert alert-warning' style='margin-top: 25px; margin-bottom:25px'><strong>The payment for the Registration ID: " + acregiddetlbl.Text + " is different!</strong></p>";
            acerrlabel.Visible = true;
        }
        //Response.Redirect(Request.RawUrl);
    }

    protected void acoffdone(object sender, EventArgs e)
    {
        if (Convert.ToInt64(acamntdetlbl.Text) == Convert.ToInt64(TextBox5.Text))
        {
            try
            {
                if (cbox2.Checked)
                {
                    SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["GECAConnectionString"].ToString());
                    conn.Open();
                    string updatecmd = "update StudMaster set approveac=0, accountantrev=null, acconftime=null, confby=null where regID=@regid";
                    SqlCommand updateCmd = new SqlCommand(updatecmd, conn);
                    updateCmd.Parameters.AddWithValue("@regid", acregiddetlbl.Text);
                    updateCmd.ExecuteNonQuery();
                    conn.Close();
                    acerrlabel.Text = "<p class='alert alert-success' style='margin-top: 25px; margin-bottom:25px'><strong>Payment state has been changed for Registration ID: " + acregiddetlbl.Text + "!</strong></p>";
                    acerrlabel.Visible = true;
                }
                else
                {
                    acerrlabel.Text = "<p class='alert alert-danger' style='margin-top: 25px; margin-bottom:25px'><strong>Have you confirmed to change the payment state ?</strong></p>";
                    acerrlabel.Visible = true;
                }
            }
            catch (Exception)
            {
                Response.Write("<script>alert('something really messy happened!\nPlease try again!');</script>");
            }
        }
        else
        {
            Div2.Visible = true;
            acerrlabel.Text = "<p class='alert alert-warning' style='margin-top: 25px; margin-bottom:25px'><strong>The payment for the Registration ID: " + acregiddetlbl.Text + " is different!</strong></p>";
            acerrlabel.Visible = true;
        }
        //Response.Redirect(Request.RawUrl);
    }

    protected void countall()
    {
        SqlDataAdapter ap = new SqlDataAdapter("select * from StudMaster", conn);
        DataSet ds = new DataSet();
        conn.Open();
        ap.Fill(ds);
        Label4.Text = ds.Tables[0].Rows.Count.ToString();
        Label8.Text = ds.Tables[0].Rows.Count.ToString();
        conn.Close();
    }

    protected void countappr()
    {
        SqlDataAdapter ap = new SqlDataAdapter("select * from StudMaster where approvess='True'", conn);
        DataSet ds = new DataSet();
        conn.Open();
        ap.Fill(ds);
        Label5.Text = ds.Tables[0].Rows.Count.ToString();
        conn.Close();
    }
    protected void countconf()
    {
        SqlDataAdapter ap = new SqlDataAdapter("select * from StudMaster where approveac='True'", conn);
        DataSet ds = new DataSet();
        conn.Open();
        ap.Fill(ds);
        Label9.Text = ds.Tables[0].Rows.Count.ToString();
        conn.Close();
    }

    protected void apprstatchange(object sender, EventArgs e)
    {
        changeapprstatus.Visible = true;
    }

    

    protected void apprfinlist(object sender, EventArgs e)
    {
        changeapprstatus.Visible = false;
        regformssnewusr.Visible = false;
        resssoffiframe.Visible = true;
        iframeText.Text = "Approved Candidates";
        hui.Visible = true;
        hui.Src = "./io/resview.aspx?res=5";
        hui.Style.Add("width", "100%");
        hui.Style.Add("height", "700px");
    }

    protected void usrsslist(object sender, EventArgs e)
    {
        changeapprstatus.Visible = false;
        regformssnewusr.Visible = false;
        resssoffiframe.Visible = true;
        iframeText.Text = "<h3>Authorised Users</h3><br/><span style='color: green; font-size: 14px; '><strong><u>ssc01</u>:Admission Authority&nbsp;&nbsp;&nbsp;<u>ssc00</u>:Clerk</strong></span>";
        hui.Visible = true;
        hui.Src = "./io/userview.aspx?res=5ahhhd0...035454sadfa af sFSBSDFVSFSFNSFVSNFvsfsfnvdsvSF54198455DFSJNFD";
        hui.Style.Add("width", "100%");
        hui.Style.Add("height", "450px");
    }

    protected void addssusr(object sender, EventArgs e)
    {
        changeapprstatus.Visible = false;
        regformssnewusr.Visible = true;
        resssoffiframe.Visible = true;
        iframeText.Text = "Add new user";
        hui.Visible = false;
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        func_signup();
    }

    public void func_signup()
    {
        string em = emailAss.Text.ToLower();
        string pa = newpasswdss.Text;
        string quer = "SELECT mobno from [GecaAuths] where username = @username";
        SqlParameter para = new SqlParameter();
        para.ParameterName = "@username";
        para.Value = newunamess.Text;
        string i = null;
        using (conn)
        {
            conn.Open();
            using (SqlCommand command = new SqlCommand(quer, conn))
            {
                command.Parameters.Add(para);
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    i = reader["mobno"].ToString();
                }
            }
            conn.Close();
        }
        if (i == null)
        {
            using (StudMasterClassDataContext context = new StudMasterClassDataContext())
            {
                GecaAuth studmas = new GecaAuth();
                studmas.password = pa;
                studmas.email = em;
                studmas.cadre = newcadress.Text;
                studmas.mobno = mobNss.Text;
                studmas.username = newunamess.Text;
                context.GecaAuths.InsertOnSubmit(studmas);
                context.SubmitChanges();
            }
            ScriptManager.RegisterClientScriptBlock(Page, Page.GetType(), "InsertedMessage", "alert('Registration Successful! Please check out the Email for furthure details.\nHave a nice Day(Night)!');", true);
            Response.Write("<script>alert('Registration Successful!')</script>");
        }
        else Response.Write("<script>alert('Err... Username not available!')</script>");
    }

    protected void conffinlist(object sender, EventArgs e)
    {
        changeconfstatus.Visible = false;
        resacoffiframe.Visible = true;
        Label10.Text = "Confirmed Candidates";
        Iframe1.Visible = true;
        Iframe1.Src = "./io/resview.aspx?res=6";
        Iframe1.Style.Add("width", "100%");
        Iframe1.Style.Add("height", "700px");
    }
    

    protected void confchangestat(object sender, EventArgs e)
    {
        resacoffiframe.Visible = false;
        changeconfstatus.Visible = true;
    }
    protected void usraclist(object sender, EventArgs e)
    {
        changeconfstatus.Visible = false;
        resacoffiframe.Visible = true;
        Label10.Text = "<h3>Authorised Users</h3><br/><span style='color: green; font-size: 14px; '><strong><u>acc10</u>:Accountant&nbsp;&nbsp;&nbsp;<u>acc11</u>:Cashier</strong></span>";
        Iframe1.Visible = true;
        Iframe1.Src = "./io/userview.aspx?res=6SJGKSFKjgsj5sgag56546dsgfs...sgfssdg sS5 S6D4G6S46SD44GSgs hjdhbg";
        Iframe1.Style.Add("width", "100%");
        Iframe1.Style.Add("height", "450px");
    }

    protected void addacusr(object sender, EventArgs e)
    {
        regformacnewusr.Visible = true;
        resacoffiframe.Visible = true;
        Label10.Text = "Add new user";
        Iframe1.Visible = false;
    }

    protected void Button2_Click(object sender, EventArgs e)
    {
        func_signup2();
    }

    public void func_signup2()
    {
        string em = newemailac.Text.ToLower();
        string pa = newpassac.Text;
        string quer = "SELECT mobno from [GecaAuths] where username = @username";
        SqlParameter para = new SqlParameter();
        para.ParameterName = "@username";
        para.Value = newunameac.Text;
        string i = null;
        using (conn)
        {
            conn.Open();
            using (SqlCommand command = new SqlCommand(quer, conn))
            {
                command.Parameters.Add(para);
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    i = reader["mobno"].ToString();
                }
            }
            conn.Close();
        }
        if (i == null)
        {
            using (StudMasterClassDataContext context = new StudMasterClassDataContext())
            {
                GecaAuth studmas = new GecaAuth();
                studmas.password = pa;
                studmas.email = em;
                studmas.cadre = newcadreac.Text;
                studmas.mobno = newmobnoac.Text;
                studmas.username = newunameac.Text;
                context.GecaAuths.InsertOnSubmit(studmas);
                context.SubmitChanges();
            }
            ScriptManager.RegisterClientScriptBlock(Page, Page.GetType(), "InsertedMessage", "alert('Registration Successful! Please check out the Email for furthure details.\nHave a nice Day(Night)!');", true);
            Response.Write("<script>alert('Registration Successful!')</script>");
        }
        else Response.Write("<script>alert('Err... Username not available!')</script>");
    }

}
