﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class adminmas : System.Web.UI.Page
{
    DataTable dt;

    SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["GECAConnectionString"].ToString());
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["admin"] == null)
        {
            BindGrid();
        }
        else
        {
            Response.Redirect("index.aspx");
        }

    }

    public void BindGrid()
    {
        try
        {
            SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["GECAConnectionString"].ToString());
            conn.Open();
            string cmd = "select * from StudMaster";
            SqlDataAdapter dAdapter = new SqlDataAdapter(cmd, conn);
            DataSet ds = new DataSet();
            dAdapter.Fill(ds);
            dt = ds.Tables[0];
            GridView1.DataSource = dt;
            GridView1.DataBind();

        }
        catch (SqlException ex)
        {
            System.Console.Error.Write(ex.Message);

        }

    }



    protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        int index = Convert.ToInt32(e.CommandArgument);
        if (e.CommandName.Equals("detail"))
        {
            GridViewRow gvrow = GridView1.Rows[index];
            lblRegId.Text = HttpUtility.HtmlDecode(gvrow.Cells[0].Text).ToString();
            string quer = "SELECT * FROM studMaster where regID= @lblreg";
            SqlParameter para = new SqlParameter();
            para.ParameterName = "@lblreg";
            para.Value = HttpUtility.HtmlDecode(gvrow.Cells[0].Text).ToString();
            using (SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["GECAConnectionString"].ToString()))
            {
                conn.Open();
                using (SqlCommand command = new SqlCommand(quer, conn))
                {
                    command.Parameters.Add(para);
                    SqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        namelbl.Text = reader["name"].ToString();
                        RegIddet.Text = reader["regID"].ToString();
                        addrlbl.Text = reader["addr"].ToString();
                        mobnolbl.Text = reader["mobno"].ToString();
                        emaillbl.Text = reader["email"].ToString();
                        //genderlbl.Text = reader["gender"].ToString();
                        doblbl.Text = reader["dob"].ToString();
                        religiolbl.Text = reader["religion"].ToString();
                        communlbl.Text = reader["commun"].ToString();
                        astreamlbl.Text = reader["astream"].ToString();
                        ayearlbl.Text = reader["ayear"].ToString();
                        phlbl.Text = reader["isph"].ToString();
                        nrilbl.Text = reader["isnri"].ToString();
                        forelbl.Text = reader["isforeign"].ToString();
                        yofalbl.Text = reader["yofadmis"].ToString();
                        tofalbl.Text = reader["typeofadmis"].ToString();
                        cidlbl.Text = reader["cid"].ToString();
                        cshiftlbl.Text = reader["cshift"].ToString();
                        cyearlbl.Text = reader["cyear"].ToString();
                        string a = reader["dp"].ToString();
                        dp2lbl.Text = "<img src='" + a + "' style='width: 136px; height: 167px; left: 0; top: 0;'></img>";
                    }
                }
                conn.Close();
            }

            lblResult.Visible = false;
            System.Text.StringBuilder sb = new System.Text.StringBuilder();
            sb.Append(@"<script type='text/javascript'>");
            sb.Append("$('#detailModal').modal('show');");
            sb.Append(@"</script>");
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "DetailModalScript", sb.ToString(), false);
        }
        else if (e.CommandName.Equals("editRecord"))
        {
            GridViewRow gvrow = GridView1.Rows[index];
            lblRegId.Text = HttpUtility.HtmlDecode(gvrow.Cells[1].Text).ToString();
            string quer = "SELECT * FROM StudMaster where regID= @lblreg";
            //SqlCommand rquer = new SqlCommand("SELECT count(*) from hostelMaster where roomno=@rnum");
            SqlParameter para = new SqlParameter();
            para.ParameterName = "@lblreg";
            para.Value = HttpUtility.HtmlDecode(gvrow.Cells[1].Text).ToString();
            using (SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["GECAConnectionString"].ToString()))
            {
                conn.Open();
                using (SqlCommand command = new SqlCommand(quer, conn))
                {
                    command.Parameters.Add(para);
                    SqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        nameedit.Text = reader["name"].ToString();
                        lblRegId.Text = reader["regID"].ToString();
                        addredit.Text = reader["addr"].ToString();
                        mobnoedit.Text = reader["mobno"].ToString();
                        emailedit.Text = reader["email"].ToString();
                        genderedit.Text = reader["gender"].ToString();
                        dobedit.Text = reader["dob"].ToString();
                        religioedit.Text = reader["religion"].ToString();
                        communedit.Text = reader["commun"].ToString();
                        astreamedit.Text = reader["astream"].ToString();
                        ayearedit.Text = reader["ayear"].ToString();
                        phedit.Text = reader["isph"].ToString();
                        nriedit.Text = reader["isnri"].ToString();
                        foreedit.Text = reader["isforeign"].ToString();
                        yofaedit.Text = reader["yofadmis"].ToString();
                        tofaedit.Text = reader["typeofadmis"].ToString();
                        cidedit.Text = reader["cid"].ToString();
                        cshiftedit.Text = reader["cshift"].ToString();
                        cyearedit.Text = reader["cyear"].ToString();
                        string a = reader["dp"].ToString();
                        dp1.Text = "<img src='" + a + "' style='width: 136px; height: 167px; left: 0; top: 0;'></img>";
                    }
                }
                conn.Close();
                //}  
                //}
                // }
                conn.Close();
            }

            lblResult.Visible = false;
            System.Text.StringBuilder sb = new System.Text.StringBuilder();
            sb.Append(@"<script type='text/javascript'>");
            sb.Append("$('#editModal').modal('show');");
            sb.Append(@"</script>");
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "EditModalScript", sb.ToString(), false);


        }
        else if (e.CommandName.Equals("deleteRecord"))
        {
            string code = GridView1.DataKeys[index].Value.ToString();
            hfCode.Value = code;
            System.Text.StringBuilder sb = new System.Text.StringBuilder();
            sb.Append(@"<script type='text/javascript'>");
            sb.Append("$('#deleteModal').modal('show');");
            sb.Append(@"</script>");
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "DeleteModalScript", sb.ToString(), false);
        }

    }

    // Handles Update Button Click Event
    protected void btnSave_Click(object sender, EventArgs e)
    {
        string code = lblRegId.Text;

        try
        {

            SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["GECAConnectionString"].ToString());
            conn.Open();
            string updtcmd = "update StudMaster set name=@name1, addr=@addr1, mobno=@mobno1, email=@email1, dob=@dob1, gender=@gender1, yofadmis=@yofadmis1, typeofadmis=@typeofadmis1, astream=@astream1, ayear=@ayear1, cid=@cid1, cshift=@cshift1 where regID=@code";
            SqlCommand delCmd = new SqlCommand(updtcmd, conn);
            delCmd.Parameters.AddWithValue("@code", code);
            delCmd.Parameters.AddWithValue("@name1", nameedit.Text);
            delCmd.Parameters.AddWithValue("@addr1", addredit.Text);
            delCmd.Parameters.AddWithValue("@mobno1", mobnoedit.Text);
            delCmd.Parameters.AddWithValue("@email1", emailedit.Text);
            delCmd.Parameters.AddWithValue("@dob1", dobedit.Text);
            delCmd.Parameters.AddWithValue("@gender1", genderedit.Text);
            delCmd.Parameters.AddWithValue("@yofadmis1", yofaedit.Text);
            delCmd.Parameters.AddWithValue("@typeofadmis1", tofaedit.Text);
            delCmd.Parameters.AddWithValue("@cid1", cidedit.Text);
            delCmd.Parameters.AddWithValue("@cshift1", cshiftedit.Text);
            delCmd.Parameters.AddWithValue("@cyear1", cyearedit.Text);
            delCmd.Parameters.AddWithValue("@astream1", astreamedit.Text);
            delCmd.Parameters.AddWithValue("@ayear1", ayearedit.Text);
            delCmd.Parameters.AddWithValue("@commun1", communedit.Text);
            delCmd.Parameters.AddWithValue("@religion1", religioedit.Text);
            delCmd.Parameters.AddWithValue("@isnri1", nriedit.Text);
            delCmd.Parameters.AddWithValue("@isforeign1", foreedit.Text);
            delCmd.Parameters.AddWithValue("@isph1", phedit.Text);
            delCmd.ExecuteNonQuery();
            conn.Close();
            BindGrid();
            System.Text.StringBuilder sb = new System.Text.StringBuilder();
            sb.Append(@"<script type='text/javascript'>");
            sb.Append("alert('Records Updated Successfully');");
            sb.Append("$('#editModal').modal('hide');");
            sb.Append(@"</script>");
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "EditHideModalScript", sb.ToString(), false);

        }
        catch (SqlException me)
        {
            System.Console.Error.Write(me.InnerException.Data);
        }
        Response.Redirect(Request.RawUrl);
        //executeUpdate(code, population, countryname, continent);
    }



    //Handles Delete button click in delete modal popup
    protected void btnDelete_Click(object sender, EventArgs e)
    {
        string code = hfCode.Value;
        try
        {
            SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["GECAConnectionString"].ToString());
            conn.Open();
            string deletecmd = "delete from StudMaster where regID=@code";
            SqlCommand delCmd = new SqlCommand(deletecmd, conn);
            delCmd.Parameters.AddWithValue("@code", code);
            delCmd.ExecuteNonQuery();
            conn.Close();
            BindGrid();
            System.Text.StringBuilder sb = new System.Text.StringBuilder();
            sb.Append(@"<script type='text/javascript'>");
            sb.Append("alert('Record deleted Successfully');");
            sb.Append("$('#deleteModal').modal('hide');");
            sb.Append(@"</script>");
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "delHideModalScript", sb.ToString(), false);
            //Response.Redirect();
        }
        catch (SqlException me)
        {
            System.Console.Write(me.Message);
        }
        finally
        {
            Response.Redirect(Request.RawUrl);
        }
    }
    protected void lgbutt_Click(object sender, EventArgs e)
    {
        Session.Clear();
        Session.RemoveAll();
        Session.Abandon();
        Response.Redirect("index.aspx");
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        Response.Redirect("exp.aspx");
    }
}