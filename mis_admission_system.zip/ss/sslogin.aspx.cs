﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class sslogin : System.Web.UI.Page
{

    SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["GECAConnectionString"].ToString());
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        /* if (IsValidLogin(username.Text, password.Text))
         {
             Session["student"] = username.Text;
             Response.Redirect("dashboard.aspx");
         }
         else
         {
             errlabel.Text = "(✖╭╮✖) Invalid Credentials! Who are you?! ノ(ಠ_ಠ)ノ";
         }*/
        if (IsPostBack)
        {
            if(username.Text != "adminss")
            {
                con.Open();
                SqlCommand usercomm = new SqlCommand("select count(*) from Gecausers where email =@email", con);
                usercomm.Parameters.AddWithValue("@email", "GECASS" + username.Text);
                int temp = Convert.ToInt32(usercomm.ExecuteScalar().ToString());
                con.Close();


                if (temp == 1)
                {
                    con.Open();
                    //string checkpass = "select Password from Gecausers where regID ='" + username.Text + "'";
                    SqlCommand passcomm = new SqlCommand("select Password from Gecausers where email = @email", con);
                    passcomm.Parameters.AddWithValue("@email", "GECASS" + username.Text);
                    string passwordDB = passcomm.ExecuteScalar().ToString().Replace(" ", "");

                    if (passwordDB == password.Text)
                    {
                        Session["studsec"] = username.Text;
                        if (Session["studsec"].ToString() == "admin")
                        {
                            Response.Redirect("StudMaster.aspx");
                        }
                        else Response.Redirect("office.aspx");
                    }
                    else
                    {
                        errlabel.Text = "<span>Invalid Password. (✖╭╮✖)</span>";
                    }
                }
                else errlabel.Text = "<span>Invalid Username! Who are you?! ノ(ಠ_ಠ)ノ</span>";
            }
            else
            {
                Session["studsecoffi"] = username.Text;
                Response.Redirect("office.aspx");
            }
        }
    }
}