﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;


public partial class io_userview : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
            try
            {
                var a = Request.QueryString["res"].ToString();
                if (a == "5ahhhd0...035454sadfa af sFSBSDFVSFSFNSFVSNFvsfsfnvdsvSF54198455DFSJNFD") Bindss();
                else if (a == "6SJGKSFKjgsj5sgag56546dsgfs...sgfssdg sS5 S6D4G6S46SD44GSgs hjdhbg") Bindac();
            }
            catch (Exception)
            {
                Response.Redirect("../http404.html");
            }
        
    }
    public void Bindac()
    {
        try
        {
            SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["GECAConnectionString"].ToString());
            conn.Open();
            string cmd = "select * from GecaAuths where cadre like 'acc%'";
            SqlDataAdapter dAdapter = new SqlDataAdapter(cmd, conn);
            DataSet ds = new DataSet();
            dAdapter.Fill(ds);
            DataTable dt = ds.Tables[0];
            GridView1.DataSource = dt;
            GridView1.DataBind();
            GridView1.HeaderRow.TableSection = TableRowSection.TableHeader;
            GridView1.FooterRow.TableSection = TableRowSection.TableFooter;
        }
        catch (SqlException ex)
        {
            System.Console.Error.Write(ex.Message);

        }
    }

    public void Bindss()
    {
        try
        {
            SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["GECAConnectionString"].ToString());
            conn.Open();
            string cmd = "select * from GecaAuths where cadre like 'ssc%'";
            SqlDataAdapter dAdapter = new SqlDataAdapter(cmd, conn);
            DataSet ds = new DataSet();
            dAdapter.Fill(ds);
            DataTable dt = ds.Tables[0];
            GridView1.DataSource = dt;
            GridView1.DataBind();
            GridView1.HeaderRow.TableSection = TableRowSection.TableHeader;
            GridView1.FooterRow.TableSection = TableRowSection.TableFooter;
        }
        catch (SqlException ex)
        {
            System.Console.Error.Write(ex.Message);

        }
    }
}