﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class changestat : System.Web.UI.Page
{
    SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["GECAConnectionString"].ToString());

    protected void Page_Load(object sender, EventArgs e)
    {

        if (Session["studsecoffi7658317tfkynuhgvrhy354"] != null)
        {
            changeapprtable.Visible = false;
            searbuttssoff();
        }
        else Response.Redirect("http404.html");
        
    }

    protected void searbuttssoff()
    {
        try
        {
            string awe = Request.QueryString["rid"].ToString();
            string quer = "SELECT * FROM StudMaster where regID= @lblreg";
            SqlParameter para = new SqlParameter();
            para.ParameterName = "@lblreg";
            para.Value = awe;
            string ag = null;
            string agt = null;
            string ahe = null;
            using (conn)
            {
                conn.Open();
                using (SqlCommand command = new SqlCommand(quer, conn))
                {
                    command.Parameters.Add(para);
                    SqlDataReader reader = command.ExecuteReader();
                    if (reader.HasRows)
                    {
                        Label37.Visible = false;
                        changeapprtable.Visible = true;
                        while (reader.Read())
                        {
                            Label15.Text = reader["name"].ToString();
                            Label13.Text = reader["regID"].ToString();
                            Label18.Text = reader["addr"].ToString();
                            Label19.Text = reader["mobno"].ToString();
                            Label20.Text = reader["email"].ToString();
                            Label22.Text = reader["gender"].ToString();
                            Label21.Text = reader["dob"].ToString();
                            Label28.Text = reader["religion"].ToString();
                            Label29.Text = reader["commun"].ToString();
                            Label16.Text = reader["astream"].ToString();
                            Label17.Text = reader["ayear"].ToString();
                            Label30.Text = reader["isph"].ToString();
                            Label32.Text = reader["isnri"].ToString();
                            Label31.Text = reader["isforeign"].ToString();
                            Label23.Text = reader["yofadmis"].ToString();
                            Label24.Text = reader["typeofadmis"].ToString();
                            Label25.Text = reader["cid"].ToString();
                            Label26.Text = reader["cshift"].ToString();
                            Label27.Text = reader["cyear"].ToString();
                            Label33.Text = reader["apprby"].ToString();
                            ag = reader["approvess"].ToString();
                            agt = reader["approveac"].ToString();
                            Label34.Text = reader["ssapprtime"].ToString();
                            ahe = reader["acconftime"].ToString();
                            string a = reader["dp"].ToString();
                            Label35.Text = reader["studsecrev"].ToString();
                            Label14.Text = "<img src='../" + a + "' style='width: 136px; height: 167px; left: 0; top: 0;'></img>";
                        }
                        conn.Close();
                    }
                    else
                    {
                        eeeee.Visible = false;
                        CheckBox1.Visible = false;
                        Button4.Visible = false;
                        Label35.Visible = false;
                        Label37.Text = "<p class='alert alert-danger' style='margin-top: 25px; margin-bottom:25px'><strong>Err... Invalid Registration ID!</strong></p>";
                        Label37.Visible = true;
                    }
                }
                conn.Close();
                if (ag == "False")
                {
                    eeeee.Visible = false;
                    CheckBox1.Visible = false;
                    Button4.Visible = false;
                    Label35.Enabled = false;
                    Label37.Text = "<p class='alert alert-danger' style='margin-top: 25px; margin-bottom:25px'><strong>This user is not approved by Student Section!</strong></p>";
                    Label37.Visible = true;
                }
                if (agt == "True")
                {
                    eeeee.Visible = false;
                    Label37.Text = "<p class='alert alert-danger' style='margin-top: 25px; margin-bottom:25px'><strong>Accounts Section has already Confirmed the fees payment for this Registration ID ...</strong></p>";
                    Label37.Visible = true;
                }
                else
                {
                    changeapprtable.Visible = true;
                    eeeee.Visible = true;
                    CheckBox1.Enabled = true;
                    Button4.Enabled = true;
                }
            }
        }
        catch (Exception)
        {
            Response.Write("<script>alert('something really messy happened!\nPlease try again!');</script>");
        }
    }
    protected void ssoffdone(object sender, EventArgs e)
    {
        try
        {
            if (CheckBox1.Checked)
            {
                SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["GECAConnectionString"].ToString());
                conn.Open();
                string updatecmd = "update StudMaster set approvess=0, fees=null, ssapprtime=null, apprby=null, studsecrev=null where regID=@regid";
                SqlCommand updateCmd = new SqlCommand(updatecmd, conn);
                updateCmd.Parameters.AddWithValue("@regid", Label13.Text);
                updateCmd.ExecuteNonQuery();
                conn.Close();
                Label37.Text = "<p class='alert alert-success' style='margin-top: 25px; margin-bottom:25px'><strong>Approval state for Registration ID: " + Label13.Text + " has been Changed!</strong></p>";
                Label37.Visible = true;
                CheckBox1.Visible = false;
                Button4.Visible = false;
            }
            else Response.Write("<script>alert('Have you confirmed to change the approval state?')</script>");
        }
        catch (Exception)
        {
            Response.Write("<script>alert('something really messy happened!\nPlease try again!');</script>");
        }
    }


}


