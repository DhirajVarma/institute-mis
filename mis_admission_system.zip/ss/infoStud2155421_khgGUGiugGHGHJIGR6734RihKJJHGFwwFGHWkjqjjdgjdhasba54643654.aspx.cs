﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class infoStud2155421 : System.Web.UI.Page
{
	SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["GECAConnectionString"].ToString());
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            string a = Request.QueryString["gid"].ToString();
            binddata();
        }
        catch(Exception)
        {
            Response.Redirect("Default.aspx");
        }
    }
    protected void binddata()
    {
        string quer = "SELECT * FROM hostelMaster where RegID= @lblreg";
        SqlParameter para = new SqlParameter();
        para.ParameterName = "@lblreg";
        para.Value = Request.QueryString["gid"].ToString();
        using (conn)
        {
            conn.Open();
            using (SqlCommand command = new SqlCommand(quer, conn))
            {
                command.Parameters.Add(para);
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    namedet.Text = reader["name"].ToString();
                    RegIddet.Text = reader["RegID"].ToString();
                    roomnodet.Text = reader["roomno"].ToString();
                    addrdet.Text = reader["addr"].ToString();
                    localaddrdet.Text = reader["localaddr"].ToString();
                    mobnodet.Text = reader["selfmobNo"].ToString();
                    pmobnodet.Text = reader["parmobNo"].ToString();
                    dobdet.Text = reader["dob"].ToString();
                    religdet.Text = reader["religio"].ToString();
                    doadm.Text = reader["conftime"].ToString();
                    commundet.Text = reader["commun"].ToString();
                    astreamdet.Text = reader["astream"].ToString();
                    ayeardet.Text = reader["ayear"].ToString();
                    dp2.Text = "<img src='" + reader["path"].ToString() + "' style='height: 157px; width:119px'></img>";
                    sign2.Text = "<img src='" + reader["sign2"].ToString() + "' style='height: 45px; width:119px'></img>";
                }
            }
            conn.Close();
        }

    }
}
