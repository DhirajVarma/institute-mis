﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class regmod : System.Web.UI.Page
{
	
    SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["GECAConnectionString"].ToString());
    protected void Page_Load(object sender, EventArgs e)
    {
        iddettable2.Visible = false;
    }

    public void modifycommon(object sender, EventArgs e)
    {
        try
        {
            string quer = "SELECT * FROM StudMaster where regID= @lblreg";
            SqlParameter para = new SqlParameter();
            para.ParameterName = "@lblreg";
            para.Value = "GECAEN17" + tboxmodcom.Text;
            string ag = "False";
            string ae = "False";
            using (conn)
            {
                conn.Open();
                using (SqlCommand command = new SqlCommand(quer, conn))
                {
                    command.Parameters.Add(para);
                    SqlDataReader reader = command.ExecuteReader();
                    if (reader.HasRows)
                    {
                        errlabell.Visible = false;
                        iddettable2.Visible = true;
                        while (reader.Read())
                        {
                            nameedit.Text = reader["name"].ToString();
                            ag = reader["approveac"].ToString();
                            ae = reader["approvess"].ToString();
                            lblRegId.Text = reader["regID"].ToString();
                            addredit.Text = reader["addr"].ToString();
                            mobnoedit.Text = reader["mobno"].ToString();
                            emailedit.Text = reader["email"].ToString();
                            genderedit.Text = reader["gender"].ToString();
                            dobedit.Text = reader["dob"].ToString();
                            religioedit.Text = reader["religion"].ToString();
                            communedit.Text = reader["commun"].ToString();
                            astreamedit.Text = reader["astream"].ToString();
                            ayearedit.Text = reader["ayear"].ToString();
                            phedit.Text = reader["isph"].ToString();
                            nriedit.Text = reader["isnri"].ToString();
                            foreedit.Text = reader["isforeign"].ToString();
                            yofaedit.Text = reader["yofadmis"].ToString();
                            tofaedit.Text = reader["typeofadmis"].ToString();
                            cidedit.Text = reader["cid"].ToString();
                            cshiftedit.Text = reader["cshift"].ToString();
                            cyearedit.Text = reader["cyear"].ToString();
                            phedit.Text = reader["isph"].ToString();
                            nriedit.Text = reader["isnri"].ToString();
                            foreedit.Text = reader["isforeign"].ToString();
                            string a = reader["dp"].ToString();
                            dp1.Text = "<img src='" + a + "' style='width: 136px; height: 167px; left: 0; top: 0;'></img>";
                        }
                        if (ag == "True")
                        {
                            errlabell.Visible = true;
                            errlabell.Text = "<span style='color: #C00; font-size: 18px; font-weight: 600;margin-top: 30px'>You can not edit the data as this Registration ID has already completed the admission process!...</span>";
                            iddettable2.Visible = false;
                        }
                        else if (ae == "True")
                        {
                            errlabell.Visible = true;
                            errlabell.Text = "<span style='color: #FF5700; font-size: 18px; font-weight: 600;margin-top: 30px'>CAREFUL! This Registration ID is already approved by Student Section Authority!...</span>";
                        }
                    }
                    else
                    {
                        errlabell.Text = "<span style='color: #C00; font-size: 18px; font-weight: 600;margin-top: 30px'>Err... Invalid Registration ID!</span>";
                        errlabell.Visible = true;
                    }
                }
                conn.Close();
            }
        }
        catch (Exception)
        {
            Response.Write("<script>alert('something really messy happened!\nPlease try again!');</script>");
        }
    }

    protected void ssmoddone(object sender, EventArgs e)
    {
        try
        {
            if (cbox1.Checked)
            {
                conn.Open();
                string updtcmd = "update StudMaster set name=@name1, addr=@addr1, mobno=@mobno1, email=@email1, dob=@dob1, gender=@gender1, yofadmis=@yofadmis1, typeofadmis=@typeofadmis1, religion=@religion1, commun=@commun1, isnri=@isnri1, isforeign=@isforeign1, isph=@isph1, astream=@astream1, ayear=@ayear1, cid=@cid1, cshift=@cshift1, cyear=@cyear1 where regID=@code";
                SqlCommand delCmd = new SqlCommand(updtcmd, conn);
                delCmd.Parameters.AddWithValue("@code", lblRegId.Text);
                delCmd.Parameters.AddWithValue("@name1", nameedit.Text);
                delCmd.Parameters.AddWithValue("@addr1", addredit.Text);
                delCmd.Parameters.AddWithValue("@mobno1", mobnoedit.Text);
                delCmd.Parameters.AddWithValue("@email1", emailedit.Text);
                delCmd.Parameters.AddWithValue("@dob1", dobedit.Text);
                delCmd.Parameters.AddWithValue("@gender1", genderedit.Text);
                delCmd.Parameters.AddWithValue("@yofadmis1", yofaedit.Text);
                delCmd.Parameters.AddWithValue("@typeofadmis1", tofaedit.Text);
                delCmd.Parameters.AddWithValue("@cid1", cidedit.Text);
                delCmd.Parameters.AddWithValue("@cshift1", cshiftedit.Text);
                delCmd.Parameters.AddWithValue("@cyear1", cyearedit.Text);
                delCmd.Parameters.AddWithValue("@astream1", astreamedit.Text);
                delCmd.Parameters.AddWithValue("@ayear1", ayearedit.Text);
                delCmd.Parameters.AddWithValue("@commun1", communedit.Text);
                delCmd.Parameters.AddWithValue("@religion1", religioedit.Text);
                delCmd.Parameters.AddWithValue("@isnri1", nriedit.Text);
                delCmd.Parameters.AddWithValue("@isforeign1", foreedit.Text);
                delCmd.Parameters.AddWithValue("@isph1", phedit.Text);
                delCmd.ExecuteNonQuery();
                conn.Close();
                errlabell.Text = "<span style='color: green; font-size: 18px; font-weight: 600;margin-top: 30px'>Details has been updated for Registration ID: " + regiddetlbl.Text + "!</span>";
                errlabell.Visible = true;
            }
            else Response.Write("<script>alert('Have you confirmed the student details ?')</script>");
        }
        catch (Exception)
        {
            Response.Write("<script>alert('something really messy happened!\nPlease try again!');</script>");
        }
    }
}
