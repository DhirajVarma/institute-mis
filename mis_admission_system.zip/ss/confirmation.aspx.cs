﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;


public partial class Confirmaion : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        dnt.Text = DateTime.Now.ToString();
        string stID = Request.QueryString["gid"].ToString();
        string quer = "SELECT * FROM StudMaster where guid1= @gidu";
        SqlParameter para = new SqlParameter();
        para.ParameterName = "@gidu";
        para.Value = stID;


        using (SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["GECAConnectionString"].ToString()))
        {
            conn.Open();
            using (SqlCommand command = new SqlCommand(quer, conn))
            {
                command.Parameters.Add(para);
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    regidLabel.Text = reader["regID"].ToString();
                    nameLabel.Text = reader["name"].ToString();
                    fullNameLabel2.Text = reader["name"].ToString()+"&nbsp;";
                    addrLabel.Text = reader["addr"].ToString();
                    mobnoLabel.Text = reader["mobno"].ToString();
                    emailLabel.Text = reader["email"].ToString();
                    genderLabel.Text = reader["gender"].ToString();
                    dobLabel.Text = reader["dob"].ToString();
                    religionLabel.Text = reader["religion"].ToString();
                    communityLabel.Text = reader["commun"].ToString();
                    nriLabel.Text = reader["isnri"].ToString();
                    foreignLabel.Text = reader["isforeign"].ToString();
                    yofadmisLabel.Text = reader["yofadmis"].ToString();
                    tofadmisLabel.Text = reader["typeofadmis"].ToString();
                    astreamLabel.Text = reader["astream"].ToString();
                    astream2.Text = reader["astream"].ToString();
                    astream3.Text = reader["astream"].ToString();
                    ayearLabel.Text = reader["ayear"].ToString();
                    ayear2.Text = reader["ayear"].ToString();
                    cidLabel.Text = reader["cid"].ToString();
                    cshiftLabel.Text = reader["cshift"].ToString();
                    cyearLabel.Text = reader["cyear"].ToString();
                    ph1Label.Text = reader["isph"].ToString();
                    dp1.Text = "<img src='" + reader["dp"].ToString() + "' style='width: 136px; height: 167px; left: 0; top: 0;'></img>";
                    sign1.Text = "<img src='" + reader["upsign"].ToString() + "' style='width: 136px; height: 53px; left: 0; top: 0;'></img>";
                }
            }
            conn.Close();
        }
    }

}

