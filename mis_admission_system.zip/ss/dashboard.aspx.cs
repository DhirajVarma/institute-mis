﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class dashboard : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["student34i7563487634io68734"] != null)
        {
            try
            {
                string df = null;
                using (SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["GECAConnectionString"].ToString()))
                {
                    string comman = "select formupdtcount from StudMaster where regID= @reg";
                    using (SqlCommand command = new SqlCommand(comman, conn))
                    {
                        command.Parameters.AddWithValue("@reg", Session["student34i7563487634io68734"].ToString());
                        conn.Open();
                        command.ExecuteScalar();
                        SqlDataReader reader = command.ExecuteReader();
                        while (reader.Read())
                        {
                            df = reader["formupdtcount"].ToString();
                        }
                        conn.Close();
                        if (df == "False")
                        {
                            canupdate();
                        }
                        else cantupdate();
                    }
                }
            }
            catch (Exception)
            {
                Response.Write("<script>alert('something really messy happened!\nPlease try again!');</script>");
            }
        }
        else Response.Redirect("login.aspx");
    }

    protected void canupdate()
    {
        try
        {
            regform.Visible = true;
            uploadsec.Visible = false;
            confmain.Visible = false;
            string quer2 = "SELECT * from [StudMaster] where regID = @sess";
            SqlParameter para2 = new SqlParameter();
            para2.ParameterName = "@sess";
            para2.Value = Session["student34i7563487634io68734"].ToString();
            using (SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["GECAConnectionString"].ToString()))
            {
                conn.Open();
                using (SqlCommand command = new SqlCommand(quer2, conn))
                {
                    command.Parameters.Add(para2);
                    SqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        lblname.Text = reader["name"].ToString();
                        lbladdr.Text = reader["addr"].ToString();
                        lblmob.Text = reader["mobno"].ToString();
                        lblemail.Text = reader["email"].ToString();
                        lblreg.Text = reader["regID"].ToString();
                        lblay.Text = reader["ayear"].ToString();
                        lblas.Text = reader["astream"].ToString();
                    }
                }
                conn.Close();
            }
        }
        catch (Exception)
        {
            Response.Write("<script>alert('something really messy happened!\nPlease try again!');</script>");
        }
    }
    protected void cantupdate()
    {
        try
        {
            regform.Visible = false;
            uploadsec.Visible = false;
            confmain.Visible = true;
            string quer2 = "SELECT * from [StudMaster] where regID = @sess";
            SqlParameter para2 = new SqlParameter();
            para2.ParameterName = "@sess";
            para2.Value = Session["student34i7563487634io68734"].ToString();
            using (SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["GECAConnectionString"].ToString()))
            {
                conn.Open();
                using (SqlCommand command = new SqlCommand(quer2, conn))
                {
                    command.Parameters.Add(para2);
                    SqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        guid1Label.Text = reader["guid1"].ToString();
                        nameLabel.Text = reader["name"].ToString();
                        regIdLabel.Text = reader["regID"].ToString();
                        addrLabel.Text = reader["addr"].ToString();
                        mobnoLabel.Text = reader["mobno"].ToString();
                        emailLabel.Text = reader["email"].ToString();
                        genderLabel.Text = reader["gender"].ToString();
                        dobLabel.Text = reader["dob"].ToString();
                        religionLabel.Text = reader["religion"].ToString();
                        communityLabel.Text = reader["commun"].ToString();
                        nriLabel.Text = reader["isnri"].ToString();
                        foreignLabel.Text = reader["isforeign"].ToString();
                        yofadmisLabel.Text = reader["yofadmis"].ToString();
                        tofadmisLabel.Text = reader["typeofadmis"].ToString();
                        astreamLabel.Text = reader["astream"].ToString();
                        ayearLabel.Text = reader["ayear"].ToString();
                        cidLabel.Text = reader["cid"].ToString();
                        cshiftLabel.Text = reader["cshift"].ToString();
                        cyearLabel.Text = reader["cyear"].ToString();
                        ph1Label.Text = reader["isph"].ToString();
                        statr.Text = reader["approveac"].ToString();
                        stats.Text = reader["approvess"].ToString();
                        string a = reader["dp"].ToString();
                        dp1.Text = "<img src='" + a + "' style='width: 136px; height: 167px; left: 0; top: 0;'></img>";
                        string b = reader["upsign"].ToString();
                        signLabel.Text = "<img src='" + b + "' style='width: 136px; height: 60px; left: 0; top: 0;'></img>";
                    }
                }
                conn.Close();
                if (statr.Text == "False" && stats.Text == "True")
                {
                    statuss.Text = "<span style='color:#FF5700;'>Your Application has been approved by Admission Authority but fees is not paid!</span>";
                    statust.Text = "Acknowledgement Page";
                }
                else if (statr.Text == "True" && stats.Text == "True")
                {
                    statuss.Text = "<span style='color:green;'>Your Application has been granted and Admission is successfull!<br/>Welcome to GECA Family!</span>";
                    statust.Text = "Confirmation Page";
                    conftabletable.Visible = false;
                }
                else if (statr.Text == "False" && stats.Text == "False")
                {
                    statuss.Text = "<span style='color:#C00;'>Your Application has not yet processed! Have you visited the Student Section?</span>";
                    statust.Text = "Acknowledgement Page";
                }
            }
        }
        catch (Exception)
        {
            Response.Write("<script>alert('something really messy happened!\nPlease try again!');</script>");
        }
    }

    protected void ButtonSubmit_Click(object sender, EventArgs e)
    {
        try
        {
                string df = null;
                using (SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["GECAConnectionString"].ToString()))
                {
                    string comman = "select formupdtcount from StudMaster where regID= @reg";
                    using (SqlCommand command = new SqlCommand(comman, conn))
                    {
                        command.Parameters.AddWithValue("@reg", Session["student34i7563487634io68734"].ToString());
                        conn.Open();
                        command.ExecuteScalar();
                        SqlDataReader reader = command.ExecuteReader();
                        while (reader.Read())
                        {
                            df = reader["formupdtcount"].ToString();
                        }
                        conn.Close();
                    if (df == "False")
                    {
                        savestudinfo();
                    }
                    else Response.Redirect("login.aspx");
                   }
                }
        }
        catch (Exception)
        {
            Response.Write("<script>alert('something really messy happened!\nPlease try again!');</script>");
        }
    }

    protected void print_Click(object sender, EventArgs e)
    {
        string a = guid1Label.Text.ToString();
        string url = "confirmation.aspx?gid=" + a;
        StringBuilder sb = new StringBuilder();
        sb.Append("<script type = 'text/javascript'>");
        sb.Append("window.open('");
        sb.Append(url);
        sb.Append("');");
        sb.Append("</script>");
        ClientScript.RegisterStartupScript(this.GetType(), "script", sb.ToString());
    }
    public void savestudinfo()
    {
        string upfolder = @"Uploads/";
        string exten = Path.GetExtension(FileUpload1.FileName);
        string ufilen = Path.ChangeExtension(FileUpload1.FileName, DateTime.Now.Ticks.ToString());
        string ufilN1 = upfolder + ufilen + exten;
        string exten2 = Path.GetExtension(FileUpload2.FileName);
        string ufilen2 = Path.ChangeExtension(FileUpload2.FileName, DateTime.Now.Ticks.ToString());
        string ufilN2 = upfolder + ufilen2 + exten2;
        string regidw = Session["student34i7563487634io68734"].ToString();
        string pht = "NA";
        if (isph.Text == "Yes")
        {
            pht = phtype.Text;
        }
        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["GECAConnectionString"].ToString());
        conn.Open();
        string updatecmd = "update StudMaster set dob=@dob, gender=@gender, yofadmis=@yoa, typeofadmis=@toa, selfregtime=@srtime, cid=@cid, cshift=@cshift, cyear=@cyear, religion=@rel, commun=@commnu, isph=@isph, isnri=@isnri, isforeign=@isfore, dp=@dp, formupdtcount=1, upsign=@sign where regID=@regid";
        SqlCommand updateCmd = new SqlCommand(updatecmd, conn);
        updateCmd.Parameters.AddWithValue("@dob", dobd.Text + "-" + dobm.Text + "-" + doby.Text);
        updateCmd.Parameters.AddWithValue("@gender", gender.Text);
        updateCmd.Parameters.AddWithValue("@yoa", yearoA.Text);
        updateCmd.Parameters.AddWithValue("@toa", typeoA.Text);
        updateCmd.Parameters.AddWithValue("@cid", cid.Text);
        updateCmd.Parameters.AddWithValue("@cshift", cshift.Text);
        updateCmd.Parameters.AddWithValue("@cyear", cyear.Text);
        updateCmd.Parameters.AddWithValue("@rel", religion.Text);
        updateCmd.Parameters.AddWithValue("@commnu", commun.Text);
        updateCmd.Parameters.AddWithValue("@isph", pht);
        updateCmd.Parameters.AddWithValue("@isnri", isnri.Text);
        updateCmd.Parameters.AddWithValue("@isfore", country.Text);
        updateCmd.Parameters.AddWithValue("@regid", regidw);
        updateCmd.Parameters.AddWithValue("@dp", ufilN1);
        updateCmd.Parameters.AddWithValue("@sign", ufilN2);
        updateCmd.Parameters.AddWithValue("@srtime", DateTime.Now.ToString());
        updateCmd.ExecuteNonQuery();
        FileUpload1.SaveAs(Server.MapPath(upfolder) + ufilen + exten);
        FileUpload2.SaveAs(Server.MapPath(upfolder) + ufilen2 + exten2);
        conn.Close();
        Response.Redirect(Request.RawUrl);
    }


}