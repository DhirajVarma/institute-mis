﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class signup : System.Web.UI.Page
{
    SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["GECAConnectionString"].ToString());
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        func_signup();
    }

    public void func_signup()
    {
        string em = emailA.Text.ToLower();
        string quer = "SELECT regID from [Gecausers] where email = @email";
        SqlParameter para = new SqlParameter();
        para.ParameterName = "@email";
        para.Value = em;
        //int i=0;
        string i = null;
        using (conn)
        {
            conn.Open();
            using (SqlCommand command = new SqlCommand(quer, conn))
            {
                command.Parameters.Add(para);
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    i = reader["regID"].ToString();
                }
            }
            conn.Close();
        }
        if (i == null)
        {
            string ac = null;
            string pa = Membership.GeneratePassword(6, 1);
            using (StudMasterClassDataContext context = new StudMasterClassDataContext())
            {
                Gecauser studmas = new Gecauser();
                studmas.Password = pa;
                studmas.email = em;
                context.Gecausers.InsertOnSubmit(studmas);
                context.SubmitChanges();
            }
            string quer2 = "SELECT regID from[Gecausers] where email = @email";
            SqlParameter para2 = new SqlParameter();
            para2.ParameterName = "@email";
            para2.Value = em;
            using (conn)
            {
                conn.Open();
                using (SqlCommand command = new SqlCommand(quer2, conn))
                {
                    command.Parameters.Add(para2);
                    SqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        ac = reader["regID"].ToString();
                    }
                }
                conn.Close();
            }
            using (StudMasterClassDataContext context = new StudMasterClassDataContext())
            {
                StudMaster studmas = new StudMaster();
                string fullName = firstN.Text + " " + middleN.Text + " " + lastN.Text;
                Guid guid1 = Guid.NewGuid();
                studmas.name = fullName.ToUpper();
                studmas.regID = ac;
                studmas.addr = addr.Text;
                studmas.mobno = mobN.Text;
                studmas.email = em;
                studmas.astream = astream.Text;
                studmas.ayear = ayear.Text;
                studmas.guid1 = guid1.ToString();
                context.StudMasters.InsertOnSubmit(studmas);
                context.SubmitChanges();
                // Response.Redirect("conf.aspx?gid=" + guid1);
                /*MailMessage msg = new MailMessage();
                msg.From = new MailAddress("varma44@ymail.com");
                msg.To.Add(em);
                msg.Subject = "Your Registration is confirmed! ";
                msg.Body = "Dear " + firstN.Text + " Your Registration to motion voter system has been confirmed. "+pa+".. Kindly note down your Voter's Identity Number(VIN) required for your login";
                SmtpClient Sc = new SmtpClient("smtp.mail.yahoo.com");
                Sc.Port = 465;
                Sc.Credentials = new NetworkCredential("varma44@ymail.com", "9423346512");
                Sc.EnableSsl = true;
                Sc.Send(msg);
                Response.Write("Sent!!! ... ");*/
                Response.Write("<script>alert('Registration Successful! Please check out the Email for furthure details.\nHave a nice Day(Night)!')</script>");
                ScriptManager.RegisterClientScriptBlock(Page, Page.GetType(), "InsertedMessage", "alert('Registration Successful! Please check out the Email for furthure details.\nHave a nice Day(Night)!');", true);
                //Response.Redirect("index.aspx");
            }
        }
        else Response.Write("<script>alert('Err... Another user is already registered with the same email address!')</script>");
        }
        
    }
