﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

public partial class aclogin : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["GECAConnectionString"].ToString());

    protected void Page_Load(object sender, EventArgs e)
    {
        Session.Clear();
    }

    protected void login_click(object sender, EventArgs e)
    {
        if (IsPostBack)
        {
            string quer = "select username, password, cadre from GecaAuths where username =@lblreg";
            //StudMasterClassDataContext context = new StudMasterClassDataContext();
            //var quer = from p in context.GecaAuths where p.username == uname.Text && p.password == pass.Text select p;

            SqlParameter para = new SqlParameter();
            para.ParameterName = "@lblreg";
            para.Value = uname.Text.ToLower();
            using (con)
            {
                con.Open();
                using (SqlCommand command = new SqlCommand(quer, con))
                {
                    command.Parameters.Add(para);
                    SqlDataReader reader = command.ExecuteReader();
                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            if (uname.Text.ToLower() == reader["username"].ToString() && pass.Text == reader["password"].ToString())
                            {
                                if (reader["cadre"].ToString().Contains("00"))
                                {
                                    Session["studsecoffi7658317tfkynuhgvrhy354"] = uname.Text;
                                }
                                else if (reader["cadre"].ToString().Contains("11"))
                                {
                                    Session["acoffidafghfasdfasdas6576867714789dsfsgfvdshgs"] = uname.Text;
                                }
                                else if (reader["cadre"].ToString().Contains("01"))
                                {
                                    Session["studsecjsghewgelkerkj"] = uname.Text;
                                }
                                else if (reader["cadre"].ToString().Contains("10"))
                                {
                                    Session["acc63582676541.504234654"] = uname.Text;
                                }
                                con.Close();
                                Response.Redirect("office.aspx");
                            }
                        }
                    }
                    else err_msg.Text = "Invalid Credentials!";
                }
                con.Close();
                err_msg.Text = "Invalid Credentials!";
            }
        }
    }
}