﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class io_resview : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        string a = Request.QueryString["res"].ToString();
        if (a == "4") { BindAll(); }
        else if (a == "5") { BindAppr(); }
        else if (a == "6") { BindConf(); }
        else Response.Redirect("../http404.html");
    }

    public void BindAll()
    {
        try
        {
            SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["GECAConnectionString"].ToString());
            conn.Open();
            string cmd = "select * from StudMaster";
            SqlDataAdapter dAdapter = new SqlDataAdapter(cmd, conn);
            DataSet ds = new DataSet();
            dAdapter.Fill(ds);
            DataTable dt = ds.Tables[0];
            GridView1.DataSource = dt;
            GridView1.DataBind();
            GridView1.HeaderRow.TableSection = TableRowSection.TableHeader;
            GridView1.FooterRow.TableSection = TableRowSection.TableFooter;
        }
        catch (SqlException ex)
        {
            System.Console.Error.Write(ex.Message);

        }
        this.GridView1.Columns[1].Visible = false;
        this.GridView1.Columns[4].Visible = false;
    }

    public void BindAppr()
    {
        try
        {
            SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["GECAConnectionString"].ToString());
            conn.Open();
            string cmd = "select * from StudMaster where approvess = 'True'";
            SqlDataAdapter dAdapter = new SqlDataAdapter(cmd, conn);
            DataSet ds = new DataSet();
            dAdapter.Fill(ds);
            DataTable dt = ds.Tables[0];
            GridView1.DataSource = dt;
            GridView1.DataBind();
            GridView1.HeaderRow.TableSection = TableRowSection.TableHeader;
            GridView1.FooterRow.TableSection = TableRowSection.TableFooter;
        }
        catch (SqlException ex)
        {
            System.Console.Error.Write(ex.Message);

        }
        this.GridView1.Columns[9].Visible = false;
        this.GridView1.Columns[8].Visible = false;
        this.GridView1.Columns[6].Visible = false;
    }

    public void BindConf()
    {
        try
        {
            SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["GECAConnectionString"].ToString());
            conn.Open();
            string cmd = "select * from StudMaster where approveac = 'True'";
            SqlDataAdapter dAdapter = new SqlDataAdapter(cmd, conn);
            DataSet ds = new DataSet();
            dAdapter.Fill(ds);
            DataTable dt = ds.Tables[0];
            GridView1.DataSource = dt;
            GridView1.DataBind();
            GridView1.HeaderRow.TableSection = TableRowSection.TableHeader;
            GridView1.FooterRow.TableSection = TableRowSection.TableFooter;
        }
        catch (SqlException ex)
        {
            System.Console.Error.Write(ex.Message);

        }
        this.GridView1.Columns[5].Visible = false;
        this.GridView1.Columns[6].Visible = false;
        this.GridView1.Columns[8].Visible = false;
    }
}